create trigger TG_INSTRUCTOR
  before insert
  on INSTRACTOR
  for each row
  begin
  select INSTRACTOR_SEQ.NEXTVAL
  into :new.id
  from dual;
end;
/

