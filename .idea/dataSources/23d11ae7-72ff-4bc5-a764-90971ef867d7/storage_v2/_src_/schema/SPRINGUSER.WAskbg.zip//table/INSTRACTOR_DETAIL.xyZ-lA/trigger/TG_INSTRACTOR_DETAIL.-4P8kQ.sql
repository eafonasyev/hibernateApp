create trigger TG_INSTRACTOR_DETAIL
  before insert
  on INSTRACTOR_DETAIL
  for each row
  begin
  select INSTRACTOR_DETAILE_SEQ.NEXTVAL
  into :new.id
  from dual;
end;
/

