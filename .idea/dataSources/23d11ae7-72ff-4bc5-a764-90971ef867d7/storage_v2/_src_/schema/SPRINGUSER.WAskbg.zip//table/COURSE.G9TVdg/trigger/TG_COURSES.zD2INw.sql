create trigger TG_COURSES
  before insert
  on COURSE
  for each row
  begin
  select courses_seq.NEXTVAL
  into :new.id
  from dual;
end;
/

